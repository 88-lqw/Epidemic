const util = require('../../utils/util.js');
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    searchText: '',//搜索文本
    cardCur: 0,
    homeData: {},
    goodsList: [],
    PageCur: 'home',
    page: 1,
    dataNull: false,
    floorstatus: false,//显示返回顶部
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if (typeof (options.cur) !== 'undefined') {
      this.setData({
        PageCur: options.cur
      })
    } else {
      this.getData()
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  },
  //tabbar跳转
  NavChange(e) {
    let url = e.currentTarget.dataset.cur
    if (url === 'publish') {
      wx.showActionSheet({
        itemList: ['防疫品供应', '防疫品采购'],
        success(res) {
          console.log(res.tapIndex)
          if (res.tapIndex === 0) {
            wx.navigateTo({
              url: '/pages/publish/supply/supply'
            })
          } else {
            wx.navigateTo({
              url: '/pages/publish/purchase/purchase'
            })
          }
        },
        fail(res) {
          console.log(res.errMsg)
        }
      })
    } else {
      this.setData({
        PageCur: url
      })
    }
  },
  //前往蓝牙测温小程序
  goBlueT(){
    util.askError('正在升级，敬请期待~')
  },
  //获取首页数据
  getData() {
    util.get(app.globalData.ip + '/home/get', {}, true).then(res => {
      this.setData({
        homeData: res.data,
        goodsList: res.data.goods
      })
    })
  },
  //获取最新商品数据
  getList(load) {
    util.get(app.globalData.ip + '/home/goods_list', {
      page: this.data.page,
      limit: 10
    }, true).then(res => {
      if (load === 'reload') {
        wx.hideNavigationBarLoading() //完成停止加载
        wx.stopPullDownRefresh() //停止下拉刷新
        wx.showToast({
          title: '刷新成功',
          duration: 1000
        })
      }
      if (res.data.length === 0) {
        this.setData({
          dataNull: this.data.page === 1 ? false : true,
          goodsList: this.data.page === 1 ? [] : this.data.goodsList
        })
        return;
      }
      this.setData({
        goodsList: load === 'more' ? this.data.goodsList.concat(res.data) : res.data,
        dataNull: res.data.length === 10 ? false : true,
      })
    })
  },
  //搜索文本
  searchInput(e) {
    this.setData({
      searchText: e.detail.value
    })
  },
  //清空搜索文本
  searchClose() {
    this.setData({
      searchText: ''
    })
  },
  //搜索商品
  searchGoods(e) {
    if (this.data.searchText === "") {
      util.askError('搜索文本不能为空')
      return false
    }
    wx.navigateTo({
      url: `/pages/goodsList/goodsList?text=${e.detail.value}`,
    })
  },
  //轮播图
  cardSwiper(e) {
    this.setData({
      cardCur: e.detail.current
    })
  },
  // 跳转
  //回到顶部
  goTop: function (e) {  // 一键回到顶部
    if (wx.pageScrollTo) {
      wx.pageScrollTo({
        scrollTop: 0
      })
    } else {
      wx.showModal({
        title: '提示',
        content: '当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。'
      })
    }
  },
  onPageScroll: function (e) {
    if (e.scrollTop > 100) {
      this.setData({
        floorstatus: true
      });
    } else {
      this.setData({
        floorstatus: false
      });
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    wx.showNavigationBarLoading() //在标题栏中显示加载
    this.data.page = 1
    this.getList('reload')
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    console.log('加载下一页')
    if (this.data.dataNull) return
    this.data.page += 1
    this.getList('more')
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})