// const app = getApp();
// const util = require('../../utils/util.js');
Component({
  properties: {

  },
  options: {
    addGlobalClass: true,
  },
  data: {
  },
  methods: {
  }
})